package basic;

import advanced.customwritable.GroupByMaxMinMedia;
import advanced.customwritable.MaxMinMediaWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import org.apache.log4j.BasicConfigurator;

import java.io.IOException;


public class MaxMinMediaPrecoPorTipoAno {
    public static void main(String args[]) throws IOException,
            ClassNotFoundException,
            InterruptedException {
        BasicConfigurator.configure();

        Configuration c = new Configuration();


        Path input = new Path("in/transactions_amostra.csv");

        Path output = new Path("output/exercicio5.txt");

        Job j = new Job(c, "MaxMinMedia");

        
        j.setJarByClass(MaxMinMediaPrecoPorTipoAno.class);
        j.setMapperClass(MaxMinMediaPrecoPorTipoAno.MapMaxMinMedia.class);
        j.setReducerClass(MaxMinMediaPrecoPorTipoAno.ReduceMaxMinMedia.class);
        j.setCombinerClass(MaxMinMediaPrecoPorTipoAno.CombineMaxMinMedia.class);




        j.setOutputKeyClass(GroupByMaxMinMedia.class);
        j.setOutputValueClass(MaxMinMediaWritable.class);
        j.setMapOutputKeyClass(GroupByMaxMinMedia.class);
        j.setMapOutputValueClass(MaxMinMediaWritable.class);

        
        FileInputFormat.addInputPath(j, input);
        FileOutputFormat.setOutputPath(j, output);

        
        System.exit(j.waitForCompletion(true) ? 0 : 1);
    }


    public static class MapMaxMinMedia extends Mapper<LongWritable, Text, GroupByMaxMinMedia, MaxMinMediaWritable> {
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {
            String texto = value.toString();
            if(texto.startsWith("country_or_area")){
                return;
            }

            String [] linhas = texto.split("\t");
            String [] valores = linhas[0].split(";");

            String ano = valores[1];
            String tipoUnidade = valores[7];

            float soma = Float.parseFloat(valores[5]);

            GroupByMaxMinMedia groupby = new GroupByMaxMinMedia(ano, tipoUnidade);

            MaxMinMediaWritable val = new MaxMinMediaWritable(1, soma);


            con.write(groupby, val);
        }
    }
    public static class CombineMaxMinMedia extends Reducer<GroupByMaxMinMedia, MaxMinMediaWritable, GroupByMaxMinMedia, MaxMinMediaWritable> {
        public void reduce(GroupByMaxMinMedia groupby, Iterable<MaxMinMediaWritable> valores, Context con)
                throws IOException, InterruptedException {
            float somaValores = 0;
            int somaN = 0;

            float maxPreco = 0;
            float minPreco = 0;

            for (MaxMinMediaWritable val : valores) {
                somaN += val.getN();
                somaValores += val.getPreco();

                float preco =  val.getPreco();

                if (preco > maxPreco) {
                    maxPreco = preco;
                }

                if (preco < minPreco || minPreco == 0){
                    minPreco = preco;
                }
            }

            con.write(groupby, new MaxMinMediaWritable(somaN, somaValores, maxPreco, minPreco));
        }
    }


    public static class ReduceMaxMinMedia  extends Reducer<GroupByMaxMinMedia, MaxMinMediaWritable, GroupByMaxMinMedia, MaxMinMediaWritable> {
        private int count = 0;
        public void reduce(GroupByMaxMinMedia groupby, Iterable<MaxMinMediaWritable> valores, Context con)
                throws IOException, InterruptedException {
            float somaValores = 0;
            int somaN = 0;

            float maxPreco = 0;
            float minPreco = 0;

            for (MaxMinMediaWritable val : valores) {
                somaN += val.getN();
                somaValores += val.getPreco();

                float preco =  val.getPreco();

                if (preco > maxPreco) {
                    maxPreco = preco;
                }

                if (preco < minPreco || minPreco == 0){
                    minPreco = preco;
                }
            }

            float media = somaValores/somaN;
            if (count < 5) {
                con.write(groupby, new MaxMinMediaWritable(media, maxPreco, minPreco));
                count++;
            }
        }
    }
}