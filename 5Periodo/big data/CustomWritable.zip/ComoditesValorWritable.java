package advanced.customwritable;

import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;

public class ComoditesValorWritable implements WritableComparable<ComoditesValorWritable> {
    private float valor;
    private int quantidade;

    public ComoditesValorWritable() {
    }

    public ComoditesValorWritable(float valor, int quantidade) {
        this.valor = valor;
        this.quantidade = quantidade;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ComoditesValorWritable that = (ComoditesValorWritable) o;
        return Float.compare(that.valor, valor) == 0 && quantidade == that.quantidade;
    }

    @Override
    public int hashCode() {
        return Objects.hash(valor, quantidade);
    }

    @Override
    public int compareTo(ComoditesValorWritable o) {
        return Integer.compare(o.hashCode(), this.hashCode());
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeFloat(valor);
        dataOutput.writeInt(quantidade);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        valor = dataInput.readFloat();
        quantidade = dataInput.readInt();
    }
}