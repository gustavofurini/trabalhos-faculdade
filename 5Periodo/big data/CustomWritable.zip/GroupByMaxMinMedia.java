package advanced.customwritable;

import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class GroupByMaxMinMedia implements WritableComparable<GroupByMaxMinMedia> {
    public String year;
    public String unitType;

    public GroupByMaxMinMedia() {

    }

    public GroupByMaxMinMedia(String year, String unitType) {
        this.year = year;
        this.unitType = unitType;

    }

    @Override
    public int compareTo(GroupByMaxMinMedia o) {
        if (o == null) {
            return 0;
        }
        int ano = year.compareTo(o.year);

        return ano == 0 ? unitType.compareTo(o.unitType) : ano;
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeUTF(year);
        dataOutput.writeUTF(unitType);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        year = dataInput.readUTF();
        unitType = dataInput.readUTF();
    }
    @Override
    public String toString() {
        return this.year + "\t" + this.unitType + "\t" ;
    }

}