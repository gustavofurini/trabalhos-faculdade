package basic;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.log4j.BasicConfigurator;
import advanced.customwritable.CommoditiesComercializadasWritable2;
import java.io.IOException;


public class Recuperacao3 {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        BasicConfigurator.configure();

        Configuration c = new Configuration();

        Path input = new Path("in/transactions_amostra.csv");

        Path output = new Path("output/recuperacao3.txt");

        Path intermediate = new Path("output/recuperacao3todosPaises.tmp");

        Job j1 = new Job(c, "commodity_1");
        j1.setJarByClass(Recuperacao3.class);
        j1.setMapperClass(MapQuantidadeComodites.class);
        j1.setReducerClass(ReduceQuantidadeComodities.class);
        j1.setCombinerClass(CombineQuantidadeComodities.class);
        j1.setMapOutputKeyClass(Text.class);
        j1.setMapOutputValueClass(DoubleWritable.class);
        j1.setOutputKeyClass(Text.class);
        j1.setOutputValueClass(DoubleWritable.class);

        FileInputFormat.addInputPath(j1, input);
        FileOutputFormat.setOutputPath(j1, intermediate);

        j1.waitForCompletion(false);

        Job j2 = new Job(c, "commodity_2");
        j2.setJarByClass(Recuperacao3.class);
        j2.setMapperClass(MapComparacao.class);
        j2.setReducerClass(ReduceComparacao.class);
        j2.setCombinerClass(CombineComparacao.class);
        j2.setMapOutputKeyClass(Text.class);
        j2.setMapOutputValueClass(CommoditiesComercializadasWritable2.class);
        j2.setOutputKeyClass(Text.class);
        j2.setOutputValueClass(CommoditiesComercializadasWritable2.class);

        FileInputFormat.addInputPath(j2, intermediate);
        FileOutputFormat.setOutputPath(j2, output);

        j2.waitForCompletion(false);
    }

    public static class MapQuantidadeComodites extends Mapper<LongWritable, Text, Text, DoubleWritable> {
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {

            String linha = value.toString();

            if (!linha.startsWith("country_or_area;")) {

                String colunas[] = linha.split(";");

                String ano = colunas[1];
                String fluxo = colunas[4];

                if (ano.equals("2018") && fluxo.equals("Import")) {

                    String commodity = colunas[3];

                    double amount = Double.parseDouble(colunas[8]);

                    Text chave = new Text(commodity);
                    DoubleWritable valor = new DoubleWritable(amount);

                    con.write(chave, valor);
                }
            }
        }
    }

    public static class CombineQuantidadeComodities extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
        public void reduce(Text key, Iterable<DoubleWritable> values, Context con)
                throws IOException, InterruptedException {

            double sum = 0.0;

            for (DoubleWritable d : values) {
                sum += d.get();
            }

            con.write(key, new DoubleWritable(sum));
        }
    }

    public static class ReduceQuantidadeComodities extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
        public void reduce(Text key, Iterable<DoubleWritable> values, Context con)
                throws IOException, InterruptedException {

            double sum = 0.0;

            for (DoubleWritable d : values) {
                sum += d.get();
            }

            con.write(key, new DoubleWritable(sum));
        }
    }


    public static class MapComparacao extends Mapper<LongWritable, Text, Text, CommoditiesComercializadasWritable2> {
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {

            String linha = value.toString();

            String linhas[] = linha.split("\t");

            String commodity = linhas[0];
            double qtd = Double.parseDouble(linhas[1]);


            Text chave = new Text("maior: ");
            CommoditiesComercializadasWritable2 valores = new CommoditiesComercializadasWritable2(commodity, qtd);

            con.write(chave, valores);
        }
    }

    public static class CombineComparacao extends Reducer<Text, CommoditiesComercializadasWritable2, Text, CommoditiesComercializadasWritable2> {
        public void reduce(Text key, Iterable<CommoditiesComercializadasWritable2> values, Context con)
                throws IOException, InterruptedException {

            double largest = 0.0;

            String commodity = "";


            for (CommoditiesComercializadasWritable2 c : values) {
                if (c.getQtd() > largest) {
                    largest = c.getQtd();
                    commodity = c.getComm();
                }
            }
            CommoditiesComercializadasWritable2 valores = new CommoditiesComercializadasWritable2(commodity, largest);

            con.write(key, valores);
        }
    }

    public static class ReduceComparacao extends Reducer<Text, CommoditiesComercializadasWritable2, Text, CommoditiesComercializadasWritable2> {
        public void reduce(Text key, Iterable<CommoditiesComercializadasWritable2> values, Context con)
                throws IOException, InterruptedException {

            double largest = 0.0;
            String commodity = "";


            for (CommoditiesComercializadasWritable2 c : values) {
                if (c.getQtd() > largest) {
                    largest = c.getQtd();
                    commodity = c.getComm();
                }
            }

            CommoditiesComercializadasWritable2 valores = new CommoditiesComercializadasWritable2(commodity, largest);

            con.write(key, valores);
        }
    }
}