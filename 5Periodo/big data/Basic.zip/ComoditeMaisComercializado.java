package basic;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.log4j.BasicConfigurator;
import advanced.customwritable.ComoditeTipoFlowWritable;
import advanced.customwritable.ComparacaoComoditeWritable;

import java.io.IOException;

public class ComoditeMaisComercializado {
    public static void main(String args[]) throws IOException,
            ClassNotFoundException,
            InterruptedException{
        BasicConfigurator.configure();

        Configuration c = new Configuration();
        Path input = new Path("in/transactions_amostra.csv");

        Path output = new Path("output/exercicio7.txt");

        Path intermediate = new Path("output/exercicio7todosComodites.tmp");

        Job j1 = new Job(c, "ComoditeMaisComercializado");

        Job j2 = new Job(c, "Compracao");

        j1.setJarByClass(ComoditeMaisComercializado.class);
        j1.setMapperClass(MapQuantidadeComodites.class);
        j1.setCombinerClass(CombineQuantidadeComodites.class);
        j1.setReducerClass(ReduceQuantidadeComodites.class);

        j2.setJarByClass(ComoditeMaisComercializado.class);
        j2.setMapperClass(MapComparacaoComodites.class);
        j2.setCombinerClass(CombineComparacaoComodites.class);
        j2.setReducerClass(ReduceComparacaoComodite.class);

        j1.setMapOutputKeyClass(ComoditeTipoFlowWritable.class);
        j1.setMapOutputValueClass(IntWritable.class);
        j1.setOutputKeyClass(ComoditeTipoFlowWritable.class);
        j1.setOutputValueClass(IntWritable.class);

        j2.setMapOutputKeyClass(Text.class);
        j2.setMapOutputValueClass(ComparacaoComoditeWritable.class);
        j2.setOutputKeyClass(Text.class);
        j2.setOutputValueClass(IntWritable.class);

        FileInputFormat.addInputPath(j1, input);
        FileOutputFormat.setOutputPath(j1, intermediate);
        FileInputFormat.addInputPath(j2, intermediate);
        FileOutputFormat.setOutputPath(j2, output);

        j1.waitForCompletion(false);
        j2.waitForCompletion(false);
    }
    public static class MapQuantidadeComodites extends Mapper<LongWritable, Text, ComoditeTipoFlowWritable, IntWritable> {  // Setar valores de entrada e saida
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException{
            String linha = value.toString();
            if (!linha.startsWith("country")){
                String colunas[] = linha.split(";");
                if(colunas[1].equals("2016")) {
                    int commodity = Integer.parseInt(colunas[2]);
                    String flow = colunas[4];
                    int qtd = 1;
                    con.write(new ComoditeTipoFlowWritable(commodity, flow), new IntWritable(qtd));
                }
            }
        }
    }
    public static class CombineQuantidadeComodites extends Reducer<ComoditeTipoFlowWritable, IntWritable, ComoditeTipoFlowWritable, IntWritable> {
        public void reduce(ComoditeTipoFlowWritable key, Iterable<IntWritable> values, Context con)
                throws IOException, InterruptedException {

            int somaQtds = 0;
            for (IntWritable v : values){
                somaQtds += v.get();
            }

            con.write(key, new IntWritable(somaQtds));
        }
    }


    public  static class ReduceQuantidadeComodites extends Reducer<ComoditeTipoFlowWritable, IntWritable, ComoditeTipoFlowWritable, IntWritable>{
        public void reduce(ComoditeTipoFlowWritable key, Iterable<IntWritable> values, Context con)
                throws IOException, InterruptedException{

            int somaQtds = 0;
            for (IntWritable v : values){
                somaQtds += v.get();
            }

            con.write(key, new IntWritable(somaQtds));
        }
    }

    public static class MapComparacaoComodites extends Mapper<LongWritable, Text, Text, ComparacaoComoditeWritable> {  // Setar valores de entrada e saida
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException{
            String linha = value.toString();

            String colunas[] = linha.split("\t");

            String commodity = colunas[0];
            String flow = colunas[1];
            int qtd = Integer.parseInt(colunas[3]);

            con.write(new Text("Chave"), new ComparacaoComoditeWritable(commodity, qtd, flow));
        }
    }

    public static class CombineComparacaoComodites extends Reducer<Text, ComparacaoComoditeWritable, Text, ComparacaoComoditeWritable> {
        public void reduce(Text key, Iterable<ComparacaoComoditeWritable> values, Context con)
                throws IOException, InterruptedException {

            int maiorSomaExport = Integer.MIN_VALUE;
            ComparacaoComoditeWritable comoditeExport = new ComparacaoComoditeWritable();
            int maiorSomaImport = Integer.MIN_VALUE;
            ComparacaoComoditeWritable comoditeImport = new ComparacaoComoditeWritable();
            int maiorSomaReExport = Integer.MIN_VALUE;
            ComparacaoComoditeWritable comoditeReExport = new ComparacaoComoditeWritable();
            int maiorSomaReImport = Integer.MIN_VALUE;
            ComparacaoComoditeWritable comoditeReImport = new ComparacaoComoditeWritable();
            for (ComparacaoComoditeWritable v : values){
                if(v.getFlow().equals("Export")){
                    if(v.getQtd() > maiorSomaExport){
                        maiorSomaExport = v.getQtd();
                        comoditeExport.setCommodity(v.getCommodity());
                        comoditeExport.setQtd(v.getQtd());
                        comoditeExport.setFlow(v.getFlow());
                    }
                }
                if(v.getFlow().equals("Import")){
                    if(v.getQtd() > maiorSomaImport){
                        maiorSomaImport = v.getQtd();
                        comoditeImport.setFlow(v.getFlow());
                        comoditeImport.setQtd(v.getQtd());
                        comoditeImport.setCommodity(v.getCommodity());
                    }
                }
                if(v.getFlow().equals("Re-Export")){
                    if(v.getQtd() > maiorSomaReExport){
                        maiorSomaReExport = v.getQtd();
                        comoditeReExport.setCommodity(v.getCommodity());
                        comoditeReExport.setQtd(v.getQtd());
                        comoditeReExport.setFlow(v.getFlow());
                    }
                }
                if(v.getFlow().equals("Re-Import")){
                    if(v.getQtd() > maiorSomaReImport){
                        maiorSomaReImport = v.getQtd();
                        comoditeReImport.setFlow(v.getFlow());
                        comoditeReImport.setQtd(v.getQtd());
                        comoditeReImport.setCommodity(v.getCommodity());
                    }
                }
            }
            con.write(new Text("Export"), comoditeExport);
            con.write(new Text("Import"), comoditeImport);
            con.write(new Text("Re-Export"), comoditeReExport);
            con.write(new Text("Re-Import"), comoditeReImport);
        }
    }


    public  static class ReduceComparacaoComodite extends Reducer<Text, ComparacaoComoditeWritable, Text, IntWritable>{
        public void reduce(Text key, Iterable<ComparacaoComoditeWritable> values, Context con)
                throws IOException, InterruptedException{

            int maiorSoma = Integer.MIN_VALUE;
            ComparacaoComoditeWritable commodity = new ComparacaoComoditeWritable();
            for (ComparacaoComoditeWritable v : values){
                if(v.getQtd() > maiorSoma){
                    maiorSoma = v.getQtd();
                    commodity.setQtd(v.getQtd());
                    commodity.setFlow(v.getFlow());
                    commodity.setCommodity(v.getCommodity());
                }
            }
            con.write(new Text(commodity.getCommodity() + commodity.getFlow()), new IntWritable(maiorSoma));
        }
    }
}