import java.util.ArrayList;

public class BHeuristica {

    private static ArrayList<Estado> visited;
    private static boolean pass = false;


 
    public static double h(Estado x, Estado fim){

        double distanciaLatitude = ( x.getLatitude() - fim.getLatitude() ),
                distanciaLongitude = ( x.getLongitude() - fim.getLongitude() );

        double distancia = Math.sqrt(distanciaLatitude * distanciaLatitude + distanciaLongitude * distanciaLongitude);

        return distancia;

    }

    public static double g(Estado x, Estado inicio){  return h(x, inicio);  }


    private static Estado distanciaMaisBaixa(ArrayList<Estado> estados, Estado goal){

        double maisBaixo = Double.MAX_VALUE;

        Estado hold = null;

        for(int i = 0; i < estados.size(); i++){

            double h_i = h(estados.get(i), goal);

            if(!visited.contains(estados.get(i)) && (h_i < maisBaixo)){
                maisBaixo = h_i;
                hold = estados.get(i);
            }

        }

        return hold;

    }


   
    private static double media(double a, double b){  return (a+b)/2; }


    
    private static Estado distanciaMaisBaixa_g_h(ArrayList<Estado> estados, Estado inicio, Estado fim){

        double maisBaixo_h = Double.MAX_VALUE, maisBaixo_g = Double.MAX_VALUE;
        Estado hold = null;

        for(int i = 0; i < estados.size(); i++){

            double h_i = h(estados.get(i), fim), g_i = g(estados.get(i), inicio);

            if(!visited.contains(estados.get(i)) && (media(g_i, h_i) < media(maisBaixo_g, maisBaixo_h))){

                maisBaixo_g = g_i;
                maisBaixo_h = h_i;
                hold = estados.get(i);

            }

        }

        return hold;

    }


    // Busca Gulosa.
    private static void busca(Grafo g, String estadoInicio, String estadoFim){

        ArrayList<Estado> estados = g.getEstado(estadoInicio).getfazFronteira();

        for(int i = 0; i < estados.size(); i++){

            Estado estado = distanciaMaisBaixa(estados, g.getEstado(estadoFim));

            if (pass || estado == null) { break; }

            if (estado.getNome().equals(estadoFim)){

                visited.add(estado);

                pass = true;

            }
            else if(!visited.contains(estado)){

                visited.add(estado);

                busca(g, estado.getNome(), estadoFim);

            }

        }

    }


    // Busca A*.
    private static void busca_a(Grafo g, String estadoInicio, String estadoFim){

        ArrayList<Estado> estados = g.getEstado(estadoInicio).getfazFronteira();

        for(int i = 0; i < estados.size(); i++){

            Estado estado = distanciaMaisBaixa_g_h(estados, g.getEstado(estadoInicio), g.getEstado(estadoFim));

            if (pass || estado == null) { break; }

            if (estado.getNome().equals(estadoFim)){

                visited.add(estado);

                pass = true;

            }
            else if(!visited.contains(estado)){

                visited.add(estado);

                busca_a(g, estado.getNome(), estadoFim);

            }

        }

    }


    

    // Retorna visitados como string.
    private static String stringfy(){

        String ret = " ";
        for(int i = 0; i < visited.size(); i++){

            ret += visited.get(i).getNome();

            if(i < visited.size()-1){ ret += " -> "; }

        }

        return ret+" ";

    }


   
    public static String buscaGulosa(Grafo g, String estadoInicio, String estadoFim){

        pass = false;

        visited = new ArrayList<>();

        visited.add(g.getEstado(estadoInicio));

        busca(g,estadoInicio,estadoFim);

        if (stringfy().contains(" "+estadoFim+" ")){
            return stringfy();
        }

        return "Estado "+estadoFim+ " não foi encontrado!\n\tCaminhos: "+stringfy();

    }


  
    public static String A_estrela(Grafo g, String estadoInicio, String estadoFim){

        pass = false;

        visited = new ArrayList<>();

        visited.add(g.getEstado(estadoInicio));

        busca_a(g,estadoInicio,estadoFim);

        if (stringfy().contains(" "+estadoFim+" ")){
            return stringfy();
        }

        return "Estado "+estadoFim+ " não foi encontrado!\n\tCaminhos: "+stringfy();

    }


    


}