package basic;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.log4j.BasicConfigurator;
import advanced.customwritable.Recuperacao2Writable;

import java.io.IOException;

public class Recuperacao2 {

    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();

        Configuration c = new Configuration();

        Path input = new Path("in/transactions_amostra.csv");

        Path output = new Path("output/recuperacao2.txt");

        Job job = new Job(c, "valorCategoria");

        job.setJarByClass(Recuperacao2.class);
        job.setMapperClass(Map.class); 
        job.setCombinerClass(Combine.class);
        job.setReducerClass(Reduce.class);



        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Recuperacao2Writable.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        FileInputFormat.addInputPath(job, input);
        FileOutputFormat.setOutputPath(job, output);

        job.waitForCompletion(false);
    }

    public static class Map extends Mapper<LongWritable, Text, Text, Recuperacao2Writable> {

        public void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {


            String line = value.toString();

            if (!line.startsWith("country_or_area;")) {

                String[] columns = line.split(";");

                String categoria = columns[9];

                double price = Double.parseDouble(columns[5]);
                int quantity = 1;

                context.write(new Text(categoria), new Recuperacao2Writable(price, quantity));
            }
        }
    }

    public static class Combine extends Reducer<Text, Recuperacao2Writable, Text, Recuperacao2Writable> {

        public void reduce(Text key, Iterable<Recuperacao2Writable> values, Context con)
                throws IOException, InterruptedException {

            double somaVals = 0;
            int somaQtds = 0;

            for (Recuperacao2Writable o : values) {
                somaVals += o.getPrice();
                somaQtds += o.getQtd();
            }
            con.write(key, new Recuperacao2Writable(somaVals, somaQtds));

        }
    }

    public static class Reduce extends Reducer<Text, Recuperacao2Writable, Text, DoubleWritable> {


        public void reduce(Text key, Iterable<Recuperacao2Writable> values, Context context)
                throws IOException, InterruptedException {

            double totalSum = 0.0;
            int totalCount = 0;

            for (Recuperacao2Writable value : values) {
                totalSum += value.getPrice();
                totalCount += value.getQtd();
            }

            double average = totalSum / totalCount;


            context.write(key, new DoubleWritable(average));


        }
    }
}

