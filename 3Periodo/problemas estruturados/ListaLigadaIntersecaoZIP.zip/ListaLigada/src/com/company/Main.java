package com.company;




public class Main {

    public static void main(String[] args) {
        ListaLigadaClass lista = new ListaLigadaClass();
        lista.inserir(7);
        lista.inserir(2);
        lista.inserir(3);
        lista.inserir(5);
        ListaLigadaClass lista2 = new ListaLigadaClass();
        lista2.inserir(7);
        lista2.inserir(9);
        lista2.inserir(6);
        lista2.inserir(0);
        ListaLigadaClass lista3 = new ListaLigadaClass();

        //for(int i=0; i < lista.getTamanho(); i ++){
            //System.out.println(lista.get(i).getValor());
            //lista3.inserir(lista.get(i).getValor());
        //}
        //for(int i=0; i < lista2.getTamanho(); i ++){
            //System.out.println(lista.get(i).getValor());
            //lista3.inserir(lista2.get(i).getValor());
        //}
        for(int i=0; i < lista2.getTamanho(); i ++){
            for(int j=0; j < lista2.getTamanho(); j ++){
               if(i == j){
                   lista3.inserir(lista2.get(j).getValor());
               }
               else{
                   break;
               }
            }
        }




        System.out.println("tamanho da lista1: " + lista.getTamanho());
        System.out.println("primeiro da lista1: " + lista.getPrimeiro().getValor());
        System.out.println("ultimo da lista1: " + lista.getUltimo().getValor());

       for(int i=0; i < lista.getTamanho(); i ++){
           System.out.println(lista.get(i).getValor());
       }
        System.out.println("=-=-=-=-=-=-=-=-=");
        //lista.remover(1);
        //System.out.println("removeu o 3");

        //for(int i = 0; i < lista.getTamanho(); i ++){
        //    System.out.println(lista.get(i).getValor());
       // }

        System.out.println("tamanho da lista2: " + lista2.getTamanho());
        System.out.println("primeiro da lista2: " + lista2.getPrimeiro().getValor());
        System.out.println("ultimo da lista2: " + lista2.getUltimo().getValor());

        for(int i = 0; i < lista2.getTamanho(); i ++){
            System.out.println(lista2.get(i).getValor());
        }

        System.out.println("LISTA 3 COM INTERSEÇÃO");
        System.out.println("tamanho da lista3: " + lista3.getTamanho());
        System.out.println("primeiro da lista3: " + lista3.getPrimeiro().getValor());
        System.out.println("ultimo da lista3: " + lista3.getUltimo().getValor());

        for(int i=0; i < lista3.getTamanho(); i ++){
            System.out.println(lista3.get(i).getValor());
        }


    }
}
