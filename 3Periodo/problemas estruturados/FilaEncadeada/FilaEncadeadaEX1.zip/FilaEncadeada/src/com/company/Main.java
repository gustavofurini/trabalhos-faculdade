package com.company;

import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {
        LinkedList<String> FilaEncadeada = new LinkedList<String>();
        FilaEncadeada.add("A");
        FilaEncadeada.add("B");
        FilaEncadeada.add("C");
        FilaEncadeada.add("D");
        FilaEncadeada.add("E");

        System.out.println(FilaEncadeada);
    }
}
