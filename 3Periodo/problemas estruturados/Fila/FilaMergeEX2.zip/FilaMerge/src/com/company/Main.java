package com.company;

public class Main {

    public static void main(String[] args) {
        Fila filaA = new Fila(2);

        filaA.adicionar(filaA, 10);
        filaA.adicionar(filaA, 55);


        Fila filaB = new Fila(4);

        filaB.adicionar(filaB, 5);
        filaB.adicionar(filaB, 15);
        filaB.adicionar(filaB, 30);
        filaB.adicionar(filaB, 70);


        Fila filaMerge = Fila.merge(filaA, filaB);

        filaMerge.mostrarElementosDaFila();



    }
}
