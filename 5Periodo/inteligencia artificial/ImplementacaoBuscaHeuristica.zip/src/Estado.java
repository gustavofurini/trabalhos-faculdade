import java.util.ArrayList;

public class Estado {

    private ArrayList<Estado> fazFronteira;
    private String nome;
    private double latitude, longitude;

    public Estado(String nome, double lat, double lon){
        this.nome = nome;
        fazFronteira = new ArrayList<Estado>();
        latitude = lat;
        longitude = lon;
    }

    public String getNome(){
        return this.nome;
    }

    public ArrayList<Estado> getfazFronteira(){
        return this.fazFronteira;
    }

    public void addEstado(Estado e){
        fazFronteira.add(e);
    }

    public double getLatitude() { return latitude; }

    public double getLongitude() { return longitude; }

}