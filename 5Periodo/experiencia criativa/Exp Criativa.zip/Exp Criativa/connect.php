<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Sttrategie";

$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_set_charset($conn, 'utf8');

// Verifica a conexão
if (!$conn) {
    die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}

// Consulta SQL para obter os dados dos jogos e suas tags
$sql = "SELECT b.name AS game_name, b.description, GROUP_CONCAT(t.name) AS tags
        FROM boardgames AS b
        INNER JOIN boardgame_tag AS bt ON b.id = bt.boardgame_id
        INNER JOIN tags AS t ON bt.tag_id = t.id
        GROUP BY b.id";

$result = mysqli_query($conn, $sql);

// Verifica se a consulta retornou resultados
if (mysqli_num_rows($result) > 0) {
    // Array para armazenar os dados dos jogos
    $games = [];

    // Loop para percorrer os resultados
    while ($row = mysqli_fetch_assoc($result)) {
        // Armazena os dados do jogo no array
        $games[] = $row;
    }
    
    // Retorna o JSON como resposta
    echo json_encode($games);
} else {
    // Se não houver resultados, retorna um JSON vazio
    echo json_encode([]);
}

// Fecha a conexão com o banco de dados
mysqli_close($conn);
