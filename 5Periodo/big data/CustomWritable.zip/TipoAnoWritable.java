package advanced.customwritable;

import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;


public class TipoAnoWritable implements WritableComparable {

    private String ano;
    private String fluxo;

    @Override
    public void readFields(DataInput in) throws IOException {
        ano = in.readUTF();
        fluxo = in.readUTF();
    }

    @Override
    public void write(DataOutput out) throws IOException {
        out.writeUTF(ano);
        out.writeUTF(fluxo);
    }

    @Override
    public int compareTo(Object o) {
        if ( o instanceof TipoAnoWritable) {
            TipoAnoWritable cy = (TipoAnoWritable) o;
            return ( this.fluxo.compareTo(cy.fluxo) + this.ano.compareTo(cy.ano) );
        }
        return -1;
    }

    @Override
    public String toString() {
        return this.ano + "\t" + this.fluxo;
    }

    public String getano() { return ano; }

    public void setano(String ano) { this.ano = ano; }

    public String getfluxo() { return fluxo; }

    public void setfluxo(String fluxo) { this.fluxo = fluxo; }

    public TipoAnoWritable() {
    }

    public TipoAnoWritable(String ano, String fluxo) {
        this.ano = ano;
        this.fluxo = fluxo;
    }

}