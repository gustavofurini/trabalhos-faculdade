package basic;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.BasicConfigurator;

import java.io.IOException;

// exercicio 1
public class BrasilTransacoes {

    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();
        Configuration c = new Configuration();

        Path input = new Path("in/transactions_amostra.csv");
        Path output = new Path("output/exercicio1.txt");

        Job j = new Job(c, "brasilTransacoesQtd");

        j.setJarByClass(BrasilTransacoes.class);
        j.setMapperClass(MapBrasilTransacoes.class);
        j.setReducerClass(ReduceBrasilTransacoes.class);
        j.setCombinerClass(CombineBrasilTransacoes.class);

        j.setOutputKeyClass(Text.class);
        j.setOutputValueClass(IntWritable.class);

        FileInputFormat.addInputPath(j, input);
        FileOutputFormat.setOutputPath(j, output);


        System.exit(j.waitForCompletion(true) ? 0 : 1);
    }

    public static class MapBrasilTransacoes extends Mapper<LongWritable, Text, Text, IntWritable> {


        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {

            String linha = value.toString();

            String valorCelula[]=linha.split(";");

            if(!valorCelula[0].equals("country_or_area")){
                if (valorCelula[0].equals("Brazil")) {
                    con.write(new Text(valorCelula[0]), new IntWritable(1));
                }
            }

        }

    }
    public static class CombineBrasilTransacoes extends Reducer<Text, IntWritable, Text, IntWritable> {

        public void reduce(Text texto, Iterable<IntWritable> values, Context con) throws IOException, InterruptedException {
            int soma = 0;
            for (IntWritable i : values){
                soma += i.get();
            }
            con.write(texto, new IntWritable(soma));
        }
    }

    public static class ReduceBrasilTransacoes extends Reducer<Text, IntWritable, Text, IntWritable> {


        public void reduce(Text texto, Iterable<IntWritable> values, Context con)
                throws IOException, InterruptedException {

            int soma = 0;

            for (IntWritable i : values){
                soma += i.get();
            }

            con.write(texto, new IntWritable(soma));

        }
    }

}