package com.company;

import javax.swing.text.html.ObjectView;

public class Fila {

    Object[] vetor = new Object[10];
    int fim = -1;
    int frente = 0;
    int qtd = 0;

    boolean cheia(){
        return(qtd == vetor.length);

    }
    boolean vazia(){
        return (qtd==0);
    }

    void adicionar(Object nome) {
        if (cheia()) {
            System.out.println("fila cheia");
        } else {
            if (fim == vetor.length - 1) {
                fim = -1;
            }
            fim++;
            vetor[fim] = nome;
            qtd++;

        }
    }
    void excluir(){
        if(vazia()){
            System.out.println("fila vazia");
        }
        else{
            vetor[frente] = null;
            for( int i = 0; i < fim; i ++){
                vetor[i] = vetor[i + 1];
            }
            vetor[fim] = null;
            --qtd;
        }
    }
    Object consultar(){
        if(vazia()){
            System.out.println("fila vazia");
            return null;
        }
        else{
            return vetor[frente];
        }
    }
    int tamanho (){
        return qtd;
    }
    void mostrarDados(){
        System.out.println("tamanho fila: " + vetor.length);
        for (int i = 0; i < vetor.length; i ++){
            System.out.println("[" + vetor[i] + "] " );
        }
    }
    void mostrarPrimeiro(){
        System.out.println("Primeiro valor: " + vetor[0]);
    }
    void mostrarUltimo(){
        System.out.println("Ultimo valor: " + vetor[5]);
    }
}
