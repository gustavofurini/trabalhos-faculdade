package com.company;

public class FilaEncadeada {
    private No no;

    public void inserir(int elemento){
        no = inserir(no, elemento);
    }

    private No inserir(No no, int elemento) {
        if (no == null) {
            return new No(elemento);
        } else {
            if (no.elemento < elemento) {
                No newNo = new No(elemento);
                newNo.proximo = no;
                return newNo;
            } else {
                no.proximo = inserir(no.proximo, elemento);
            }
        }
        return no;
    }

    private boolean procurarElemento(No no, int elemento){
        if(no == null){
            return false;
        }
        else{
            if(no.elemento == elemento){
                return true;
            }
            else{
                return procurarElemento(no.proximo, elemento);
            }
        }
    }

    public void mostraFila(){
        mostraFila(no);
    }

    private void mostraFila(No no){
        if(no != null){
            System.out.println(no.elemento);
            mostraFila(no.proximo);
        }
    }
}
