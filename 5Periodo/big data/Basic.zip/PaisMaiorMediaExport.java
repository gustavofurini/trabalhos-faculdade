package basic;

import advanced.customwritable.ComoditesValorWritable;
import advanced.customwritable.PaisMediaWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.BasicConfigurator;

import java.io.IOException;

public class PaisMaiorMediaExport {
    public static void main(String args[]) throws IOException,
            ClassNotFoundException,
            InterruptedException {
        BasicConfigurator.configure();

        Configuration c = new Configuration();


        Path input = new Path("in/transactions_amostra.csv");

        Path output = new Path("output/exercicio6.txt");

        Path intermediate = new Path("output/exercicio6todosPaises.txt");

        Job j = new Job(c, "MediaComodites");

        Job j2 = new Job(c, "PaisMaiorMedia");

        j.setJarByClass(PaisMaiorMediaExport.class);
        j.setMapperClass(PaisMaiorMediaExport.MapMediaComodites.class);
        j.setReducerClass(PaisMaiorMediaExport.ReduceMediaComodites.class);
        j.setCombinerClass(CombineMediaComodites.class);

        j2.setJarByClass(PaisMaiorMediaExport.class);
        j2.setMapperClass(PaisMaiorMediaExport.MapPaisMaiorMedia.class);
        j2.setReducerClass(PaisMaiorMediaExport.ReducePaisMaiorMedia.class);
        j2.setCombinerClass(CombinePaisMaiorMedia.class);

        j.setMapOutputKeyClass(Text.class);
        j.setMapOutputValueClass(ComoditesValorWritable.class);
        j.setOutputKeyClass(Text.class);
        j.setOutputValueClass(FloatWritable.class);

        j2.setMapOutputKeyClass(Text.class);
        j2.setMapOutputValueClass(PaisMediaWritable.class);
        j2.setOutputKeyClass(Text.class);
        j2.setOutputValueClass(FloatWritable.class);




        FileInputFormat.addInputPath(j, input);
        FileOutputFormat.setOutputPath(j, intermediate);
        FileInputFormat.addInputPath(j2, intermediate);
        FileOutputFormat.setOutputPath(j2, output);


        j.waitForCompletion(false);
        j2.waitForCompletion(false);

    }

    public static class MapMediaComodites extends Mapper<LongWritable, Text, Text, ComoditesValorWritable> {
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {

            String linha = value.toString();
            if (!linha.startsWith("country")) {
                String colunas[] = linha.split(";");
                if (colunas[4].equals("Export")) {
                    String pais = colunas[0];
                    float preco = Float.parseFloat(colunas[5]);
                    int quantidade = 1;

                    con.write(new Text(pais), new ComoditesValorWritable(preco, quantidade));
                }
            }
        }
    }
    public static class CombineMediaComodites extends Reducer<Text, ComoditesValorWritable, Text, ComoditesValorWritable>{
        public void reduce(Text key, Iterable<ComoditesValorWritable> values, Context con)
                throws IOException, InterruptedException {

            float somaPrecos = 0;
            int somaTotal = 0;

            for(ComoditesValorWritable o : values){
                somaTotal += o.getQuantidade();
                somaPrecos += o.getValor();
            }

            con.write(key, new ComoditesValorWritable(somaPrecos, somaTotal));
        }
    }


    public static class ReduceMediaComodites extends Reducer<Text, ComoditesValorWritable, Text, FloatWritable> {
        public void reduce(Text key, Iterable<ComoditesValorWritable> values, Context con)
                throws IOException, InterruptedException {

            int somaTotal = 0;
            float somaPrecos = 0;
            for (ComoditesValorWritable v : values) {
                somaTotal += v.getQuantidade();
                somaPrecos += v.getValor();
            }

            float media = somaPrecos / somaTotal;

            con.write(key, new FloatWritable(media));

        }
    }

    public static class MapPaisMaiorMedia extends Mapper<LongWritable, Text, Text, PaisMediaWritable> {
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {

            String linha = value.toString();

            String campos [] = linha.split("\t");

            String pais = campos[0];
            float media = Float.parseFloat(campos[1]);
            con.write(new Text("Chave"), new PaisMediaWritable(pais, media));
        }
    }

    public static class CombinePaisMaiorMedia extends Reducer<Text, PaisMediaWritable, Text, PaisMediaWritable>{
        public void reduce(Text key, Iterable<PaisMediaWritable> values, Context con)
                throws IOException, InterruptedException {

            String pais = null;
            float valor = Float.MIN_VALUE;

            for(PaisMediaWritable v : values){
                if(v.getValor() > valor){
                    pais = v.getPais();
                    valor = v.getValor();
                }
            }

            con.write(key, new PaisMediaWritable(pais, valor));
        }
    }


    public static class ReducePaisMaiorMedia extends Reducer<Text, PaisMediaWritable, Text, FloatWritable> {
        public void reduce(Text key, Iterable<PaisMediaWritable> values, Context con)
                throws IOException, InterruptedException {
            String pais = null;
            float valor = Float.MIN_VALUE;
            for(PaisMediaWritable v : values){
                if(v.getValor() > valor){
                    pais = v.getPais();
                    valor = v.getValor();
                }
            }
            con.write(new Text(pais), new FloatWritable(valor));
        }
    }
}
