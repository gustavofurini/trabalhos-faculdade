package basic;


import advanced.customwritable.Recuperacao1Writable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.BasicConfigurator;

import java.io.IOException;

// exercicio 2
public class Recuperacao1 {

    public static void main(String[] args) throws Exception {
        BasicConfigurator.configure();

        Configuration c = new Configuration();


        Path input = new Path("in/transactions_amostra.csv");


        Path output = new Path("output/recuperacao1.txt");


        Job j = new Job(c, "TransacoesPorFlowTipoPais");


        j.setJarByClass(Recuperacao1Writable.class);
        j.setMapperClass(MapTipoPorfluxo.class);
        j.setReducerClass(ReduceTipoPorfluxo.class);
        //j.setCombinerClass(ReduceTipoPorfluxo.class);
        j.setCombinerClass(CombineTipoPorfluxo.class);

        j.setOutputKeyClass(Recuperacao1Writable.class);
        j.setOutputValueClass(IntWritable.class);

        FileInputFormat.addInputPath(j, input);
        FileOutputFormat.setOutputPath(j, output);


        System.exit(j.waitForCompletion(true) ? 0 : 1);
    }

    public static class MapTipoPorfluxo extends Mapper<LongWritable, Text, Recuperacao1Writable, IntWritable> {

        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {

            String valorCelula[]=value.toString().split(";");
            
            String pais = value.toString().split(";")[0];
            String fluxo = value.toString().split(";")[4];
            if(!valorCelula[0].equals("country_or_area")){

                con.write(new Recuperacao1Writable(fluxo, pais), new IntWritable(1));


            }

        }

    }

    public static class CombineTipoPorfluxo extends Reducer<Recuperacao1Writable, IntWritable, Recuperacao1Writable, IntWritable> {

        public void reduce(Recuperacao1Writable word, Iterable<IntWritable> values, Context con)
                throws IOException, InterruptedException {

            int soma = 0;

            for (IntWritable i : values){
                soma += i.get();
            }

            con.write(word, new IntWritable(soma));
        }
    }




    public static class ReduceTipoPorfluxo extends Reducer<Recuperacao1Writable, IntWritable, Recuperacao1Writable, IntWritable> {

        private int count = 0;

        public void reduce(Recuperacao1Writable word, Iterable<IntWritable> values, Context con)
                throws IOException, InterruptedException {

            int soma = 0;

            for (IntWritable i : values){
                soma += i.get();
            }

            if (count < 5) {
                con.write(word, new IntWritable(soma));
                count++;
            }
        }
    }
}
