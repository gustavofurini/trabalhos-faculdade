window.addEventListener('DOMContentLoaded', (event) => {
    const scrollDownButton = document.querySelector('.scroll-down');
    const tableSection = document.querySelector('#tabela');

    scrollDownButton.addEventListener('click', () => {
        tableSection.scrollIntoView({ behavior: 'smooth' });
    });
});

$(document).ready(function() {
  $.ajax({
      url: "./connect.php",
      type: "GET",
      dataType: "json",
      success: function(response) {
          if (response.length > 0) {
              $.each(response, function(index, game) {

                tags = game.tags.split(',')
                item =  "<div class='item'>"
                item +=     "<img src='home.png' alt='Imagem do item'>"
                item +=     "<div class='content'>"
                item +=         "<div class='title-tags'>"
                item +=             "<a href='./visualizar.html' class='link-view'>"
                item +=                 "<h2>" + game.game_name + "</h2>"
                item +=                 "<div class='tags'>"

                tags.forEach(tag => {
                  item +=                     "<span class='tag'>" + tag + "</span>"
                });

                item +=                 "</div>"
                item +=             "</a>"
                item +=         "</div>"
                item +=         "<button class='expand-details'></button>"
                item +=     "</div>"
                item += "</div>"
                $(".item-teste").append(item);
              });

              
          } else {
              console.log("Nenhum jogo encontrado.");
          }
      },
      error: function(xhr, status, error) {
          console.log("Erro: " + status + " - " + error);
      }
  });
});

