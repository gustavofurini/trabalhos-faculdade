package advanced.customwritable;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Objects;


public class Recuperacao2Writable implements WritableComparable<Recuperacao2Writable> {

    private double price;
    private int qtd;

    public Recuperacao2Writable() {
    }

    public Recuperacao2Writable(double price, int qtd) {
        this.price = price;
        this.qtd = qtd;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }

    @Override
    public int compareTo(Recuperacao2Writable o) {
        return Integer.compare(o.hashCode(), this.hashCode());

    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        dataOutput.writeDouble(price);
        dataOutput.writeInt(qtd);

    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        price = dataInput.readDouble();
        qtd = dataInput.readInt();

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Recuperacao2Writable that = (Recuperacao2Writable) o;
        return Double.compare(that.price, price) == 0 && qtd == that.qtd;
    }

    @Override
    public int hashCode() {
        return Objects.hash(price, qtd);
    }
}