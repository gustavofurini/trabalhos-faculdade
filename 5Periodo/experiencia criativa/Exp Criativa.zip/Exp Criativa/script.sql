
-- Deletar o banco de dados se já existir
DROP DATABASE IF EXISTS Sttrategie;

-- Criar o banco de dados
CREATE DATABASE Sttrategie;

-- Usar o banco de dados
USE Sttrategie;

-- Criação da tabela 'boardgames'
CREATE TABLE boardgames (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    company_url VARCHAR(255),
    purchase_url VARCHAR(255)
);

-- Criação da tabela 'images'
CREATE TABLE images (
    id INT PRIMARY KEY AUTO_INCREMENT,
    boardgame_id INT NOT NULL,
    image_url VARCHAR(255),
    FOREIGN KEY (boardgame_id) REFERENCES boardgames(id)
);

-- Criação da tabela 'tags'
CREATE TABLE tags (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
);

-- Criação da tabela 'boardgame_tag'
CREATE TABLE boardgame_tag (
    id INT PRIMARY KEY AUTO_INCREMENT,
    boardgame_id INT NOT NULL,
    tag_id INT NOT NULL,
    FOREIGN KEY (boardgame_id) REFERENCES boardgames(id),
    FOREIGN KEY (tag_id) REFERENCES tags(id)
);

-- Inserção das tags/categorias
INSERT INTO tags (name) VALUES
    ('Estratégia'),
    ('Aventura'),
    ('Ficção Científica'),
    ('Terror'),
    ('Jogos de Cartas'),
    ('Cooperativo'),
    ('Competitivo'),
    ('Quebra-cabeça'),
    ('Temático'),
    ('Jogos de Festa'),
    ('Familiar'),
    ('Guerra'),
    ('Esportes'),
    ('Medicina'),
    ('Role-playing');

-- Inserção dos jogos na tabela boardgames
INSERT INTO boardgames (name, description) VALUES
    ('Monopoly', 'Monopoly é um jogo de tabuleiro clássico onde os jogadores compram e vendem propriedades para se tornarem os jogadores mais ricos.'),
    ('Catan', 'Catan é um jogo de tabuleiro estratégico onde os jogadores competem para construir assentamentos e cidades em uma ilha.'),
    ('Carcassonne', 'Carcassonne é um jogo de colocação de peças onde os jogadores constroem cidades, estradas e campos para ganhar pontos.'),
    ('Ticket to Ride', 'Ticket to Ride é um jogo de tabuleiro temático de trens onde os jogadores coletam e jogam cartas de trem correspondentes para reivindicar rotas ferroviárias.'),
    ('Dominion', 'Dominion é um jogo de cartas de construção de baralhos onde os jogadores competem para construir o baralho mais valioso.'),
    ('Pandemic', 'Pandemic é um jogo de tabuleiro cooperativo onde os jogadores trabalham juntos para prevenir a propagação de doenças pelo mundo.'),
    ('War', 'War é um jogo de tabuleiro de estratégia e guerra onde os jogadores competem para conquistar territórios e derrotar seus oponentes.'),
    ('Risk', 'Risk é um jogo de tabuleiro de estratégia de guerra onde os jogadores competem pela dominação global.'),
    ('Scythe', 'Scythe é um jogo de tabuleiro de estratégia ambientado em um cenário alternativo dos anos 1920, onde as nações lutam pelo controle de recursos.'),
    ('Dead of Winter', 'Dead of Winter é um jogo de tabuleiro de sobrevivência e traição onde os jogadores tentam sobreviver a um apocalipse zumbi.'),
    ('Coup', 'Coup é um jogo de cartas de blefe e intriga política onde os jogadores tentam descobrir a identidade dos outros jogadores e eliminar seus oponentes.'),
    ('Terraforming Mars', 'Terraforming Mars é um jogo de tabuleiro de ficção científica onde os jogadores competem para transformar Marte em um planeta habitável.'),
    ('Ticket to Ride: Europe', 'Ticket to Ride: Europe é uma versão do jogo Ticket to Ride ambientada na Europa, onde os jogadores constroem rotas ferroviárias.'),
    ('Pandemic Legacy: Season 1', 'Pandemic Legacy: Season 1 é uma versão do jogo Pandemic com elementos de campanha e narrativa, onde os jogadores enfrentam uma pandemia em evolução.'),
    ('Dixit', 'Dixit é um jogo de cartas criativo e imaginativo onde os jogadores tentam transmitir uma história ou conceito através de ilustrações.'),
    ('Terra Mystica', 'Terra Mystica é um jogo de tabuleiro de construção de civilizações onde os jogadores competem pelo controle de territórios e poder.'),
    ('7 Wonders', '7 Wonders é um jogo de cartas de construção de civilizações onde os jogadores constroem maravilhas e desenvolvem suas cidades.'),
    ('Puerto Rico', 'Puerto Rico é um jogo de tabuleiro de estratégia econômica onde os jogadores colonizam e desenvolvem a ilha de Porto Rico.'),
    ('Mansions of Madness', 'Mansions of Madness é um jogo de tabuleiro de horror e investigação onde os jogadores exploram mansões assombradas e desvendam mistérios.'),
    ('Blood Rage', 'Blood Rage é um jogo de tabuleiro de estratégia e combate viking, onde os jogadores lutam por glória antes do fim do mundo.'),
    ('Codenames', 'Codenames é um jogo de dedução e comunicação onde os jogadores tentam identificar palavras secretas com base em pistas dadas pelo líder de equipe.'),
    ('Terraforming Mars: Prelude', 'Terraforming Mars: Prelude é uma expansão do jogo Terraforming Mars que adiciona cartas de pré-jogo para aumentar a variedade e estratégia.'),
    ('Dead of Winter: A Crossroads Game', 'Dead of Winter: A Crossroads Game é uma expansão do jogo Dead of Winter que adiciona novos sobreviventes, eventos e escolhas morais.');

-- Inserção dos vínculos entre jogos e tags na tabela boardgame_tag
-- Monopoly
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (1, 7), -- Estratégia
    (1, 10), -- Jogos de Festa
    (1, 11); -- Familiar

-- Catan
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (2, 1), -- Estratégia
    (2, 10), -- Jogos de Festa
    (2, 11); -- Familiar

-- Carcassonne
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (3, 1), -- Estratégia
    (3, 10), -- Jogos de Festa
    (3, 11); -- Familiar

-- Ticket to Ride
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (4, 1), -- Estratégia
    (4, 10), -- Jogos de Festa
    (4, 11); -- Familiar

-- Dominion
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (5, 1), -- Estratégia
    (5, 6), -- Cooperativo
    (5, 11); -- Familiar

-- Pandemic
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (6, 1), -- Estratégia
    (6, 6), -- Cooperativo
    (6, 13); -- Role-playing

-- Settlers of Catan
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (7, 1), -- Estratégia
    (7, 10), -- Jogos de Festa
    (7, 11); -- Familiar

-- Terraforming Mars
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (8, 1), -- Estratégia
    (8, 3), -- Ficção Científica
    (8, 9); -- Temático

-- Codenames
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (9, 5), -- Jogos de Cartas
    (9, 10), -- Jogos de Festa
    (9, 11); -- Familiar

-- Scythe
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (10, 1), -- Estratégia
    (10, 9), -- Temático
    (10, 12); -- Negociação

-- Dead of Winter
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (11, 2), -- Aventura
    (11, 6), -- Cooperativo
    (11, 4); -- Terror

-- Gloomhaven
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (12, 1), -- Estratégia
    (12, 2), -- Aventura
    (12, 13); -- Role-playing

-- Splendor
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (13, 1), -- Estratégia
    (13, 11), -- Familiar
    (13, 14); -- Esportes

-- Terra Mystica
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (14, 1), -- Estratégia
    (14, 9), -- Temático
    (14, 11); -- Familiar

-- 7 Wonders
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (15, 1), -- Estratégia
    (15, 10), -- Jogos de Festa
    (15, 11); -- Familiar

-- Puerto Rico
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (16, 1), -- Estratégia
    (16, 9), -- Temático
    (16, 12); -- Negociação

-- Kingdomino
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (17, 1), -- Estratégia
    (17, 11), -- Familiar
    (17, 14); -- Esportes

-- Love Letter
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (18, 5), -- Jogos de Cartas
    (18, 10), -- Jogos de Festa
    (18, 11); -- Familiar

-- Azul
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (19, 1), -- Estratégia
    (19, 11), -- Familiar
    (19, 9); -- Temático

-- Pandemic Legacy: Season 1
INSERT INTO boardgame_tag (boardgame_id, tag_id) VALUES
    (20, 1), -- Estratégia
    (20, 6), -- Cooperativo
    (20, 13); -- Role-playing

SELECT b.name AS game_name, b.description, GROUP_CONCAT(t.name) AS tags
FROM boardgames AS b
INNER JOIN boardgame_tag AS bt ON b.id = bt.boardgame_id
INNER JOIN tags AS t ON bt.tag_id = t.id
GROUP BY b.name;
