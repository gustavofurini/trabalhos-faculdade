package com.company;

public class No {
    public int elemento;
    public No proximo;

    public No(int elemento){
        this.elemento = elemento;
        proximo = null;
    }
}
