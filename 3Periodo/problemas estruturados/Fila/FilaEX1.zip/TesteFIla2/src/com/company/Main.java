package com.company;

public class Main {

    public static void main(String[] args) {
        Fila fila = new Fila();

        fila.adicionar(1);
        fila.adicionar(2);
        fila.adicionar(3);
        fila.adicionar(4);
        fila.adicionar(5);
        fila.excluir();

        fila.mostrarPrimeiro();
        fila.mostrarUltimo();
        fila.mostrarDados();
    }
}
