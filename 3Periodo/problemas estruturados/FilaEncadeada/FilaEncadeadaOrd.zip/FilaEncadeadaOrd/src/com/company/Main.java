package com.company;

public class Main {

    public static void main(String[] args) {
        FilaEncadeada filaEncadeada = new FilaEncadeada();
        filaEncadeada.inserir(5);
        filaEncadeada.inserir(3);
        filaEncadeada.inserir(7);

        filaEncadeada.mostraFila();
    }
}
