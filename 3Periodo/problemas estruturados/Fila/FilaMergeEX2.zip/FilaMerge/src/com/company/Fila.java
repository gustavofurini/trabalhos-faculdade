package com.company;

public class Fila {
    private int remove;
    private int maximo = 0;
    private int dado[];

    public Fila(int tamanhoFila) {
        this.dado = new int[tamanhoFila];
        this.remove = 0;
    }



    public void adicionar(Fila f, int elemento) {
        if (this.maximo < this.dado.length) {
            this.dado[this.maximo] = elemento;
            this.maximo++;
        }
    }

    public void cheia(){
        if(this.maximo == this.dado.length){
            System.out.println("A Fila esta cheia");
        } else{
            System.out.println("A Fila não esta cheia");
        }
    }

    public boolean vazia( ){
        if(this.maximo == 0){
            return true;
        }
        return false;
    }

    public Object primeiro(){
        if (this.vazia()){
            return "A fila esta vazia !";
        }

        return this.dado[0];
    }

    public Object ultimo(){
        return this.dado[--maximo];
    }

    public Object excluir() {
        int pos = 0;
        int excluirElemento = this.dado[pos];

        for (int i = pos; i < this.maximo - 1; i++) {
            dado[i] = dado[i+1];
        }
        this.maximo--;

        return excluirElemento;

    }

    public static Fila merge(Fila fila1, Fila fila2) {
        Fila fila3 = new Fila(fila1.dado.length + fila2.dado.length);

        int proximo1 = 0;
        int proximo2 = 0;
        int proximo3 = 0;

        while (proximo1 < fila1.dado.length && proximo2 < fila2.dado.length) {
            if (fila1.dado[proximo1] <= fila2.dado[proximo2]) {
                fila3.dado[proximo3++] = fila1.dado[proximo1++];
            } else {
                fila3.dado[proximo3++] = fila2.dado[proximo2++];
            }
        }

        while (proximo1 < fila1.dado.length) {
            fila3.dado[proximo3++] = fila1.dado[proximo1++];
        }

        while (proximo2 < fila2.dado.length) {
            fila3.dado[proximo3++] = fila2.dado[proximo2++];
        }

        return fila3;
    }

    public void mostrarElementosDaFila() {
        for (int elemento : dado) {
            System.out.print(elemento + " ");
        }
        System.out.println();
    }






}
