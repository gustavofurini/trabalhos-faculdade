package basic;


import org.apache.hadoop.io.WritableComparable;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.log4j.BasicConfigurator;
import advanced.customwritable.TipoUnidadeWritable;
import advanced.customwritable.GroupByTipoUnidadeWritable;
import java.io.IOException;
import java.util.Objects;

// exercicio 4
public class MediaPrecoComoditesPorTipoAnoCategoria {

    public static void main(String args[]) throws IOException,
            ClassNotFoundException,
            InterruptedException {
        BasicConfigurator.configure();

        Configuration c = new Configuration();

        Path input = new Path("in/transactions_amostra.csv");

        Path output = new Path("output/exercicio4.txt");

        Job j = new Job(c, "MediaPrecoComoditesPorTipoAnoCategoria");


        j.setJarByClass(TipoUnidadeWritable.class);
        j.setMapperClass(MapPrecoComoditesTipoAnoCat.class);
        j.setReducerClass(ReducePrecoComoditesTipoAnoCat.class);
        j.setCombinerClass(CombinePrecoComoditesTipoAnoCat.class);
        
        j.setOutputKeyClass(GroupByTipoUnidadeWritable.class);
        j.setOutputValueClass(TipoUnidadeWritable.class);
        j.setMapOutputKeyClass(GroupByTipoUnidadeWritable.class);
        j.setMapOutputValueClass(TipoUnidadeWritable.class);


        FileInputFormat.addInputPath(j, input);
        FileOutputFormat.setOutputPath(j, output);


        System.exit(j.waitForCompletion(true) ? 0 : 1);
    }


    public static class MapPrecoComoditesTipoAnoCat extends Mapper<LongWritable, Text, GroupByTipoUnidadeWritable, TipoUnidadeWritable> {
        public void map(LongWritable key, Text value, Context con)
                throws IOException, InterruptedException {
            String texto = value.toString();
            if(texto.startsWith("country_or_area")){
                return;
            }
            
            String valorCelula[]=value.toString().split(";");
            String [] linhas = texto.split("\t");
            String [] valores = linhas[0].split(";");



            String ano = valores[1];
            String nomeComodite = valores[2];
            String tipoUnidade = valores[7];
            String categoria = valores[8];
            String flow = valores[4];
            String pais = valores[0];

            float soma = Float.parseFloat(valores[5]);

            if ((Objects.equals(pais, "Brazil")) && (Objects.equals(flow, "Export"))){
                GroupByTipoUnidadeWritable groupby = new GroupByTipoUnidadeWritable(ano, nomeComodite, tipoUnidade, categoria);

                TipoUnidadeWritable val = new TipoUnidadeWritable(1, soma);
                
                con.write(groupby, val);
            }
        }
    }
    public static class CombinePrecoComoditesTipoAnoCat extends Reducer<GroupByTipoUnidadeWritable, TipoUnidadeWritable, GroupByTipoUnidadeWritable, TipoUnidadeWritable> {
        public void reduce(GroupByTipoUnidadeWritable groupby, Iterable<TipoUnidadeWritable> values, Context con) throws IOException, InterruptedException {
            int somaN = 0;
            float somaPreco = 0;
            for (TipoUnidadeWritable val : values) {
                somaN += val.getN();
                somaPreco += val.getPrice();
            }
            con.write(groupby, new TipoUnidadeWritable(somaN, somaPreco));
        }
    }


    public static class ReducePrecoComoditesTipoAnoCat extends Reducer<GroupByTipoUnidadeWritable, TipoUnidadeWritable, GroupByTipoUnidadeWritable, FloatWritable> {
        private int count = 0;
        public void reduce(GroupByTipoUnidadeWritable groupby, Iterable<TipoUnidadeWritable> values, Context con)
                throws IOException, InterruptedException {
            float somaValores = 0;
            int somaN = 0;
            for (TipoUnidadeWritable val : values) {
                somaN += val.getN();
                somaValores += val.getPrice();
            }
            float media = somaValores/somaN;
            if(count < 5) {
                con.write(groupby, new FloatWritable(media));
                count++;
            }
        }
    }

}
