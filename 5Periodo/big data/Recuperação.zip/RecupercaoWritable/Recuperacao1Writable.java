package advanced.customwritable;

import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;


public class Recuperacao1Writable implements WritableComparable {

    private String fluxo;
    private String pais;

    @Override
    public void readFields(DataInput in) throws IOException {
        fluxo = in.readUTF();
        pais = in.readUTF();
    }

    @Override
    public void write(DataOutput out) throws IOException {
        out.writeUTF(fluxo);
        out.writeUTF(pais);
    }

    @Override
    public int compareTo(Object o) {
        if ( o instanceof Recuperacao1Writable) {
            Recuperacao1Writable cy = (Recuperacao1Writable) o;
            return ( this.pais.compareTo(cy.pais) + this.fluxo.compareTo(cy.fluxo) );
        }
        return -1;
    }

    @Override
    public String toString() {
        return this.fluxo + "\t" + this.pais;
    }

    public String getFluxo() { return fluxo; }

    public void setFluxo(String fluxo) { this.fluxo = fluxo; }

    public String getPais() { return pais; }

    public void setPais(String fluxo) { this.pais = fluxo; }

    public Recuperacao1Writable() {
    }

    public Recuperacao1Writable(String fluxo, String pais) {
        this.fluxo = fluxo;
        this.pais = pais;
    }

}